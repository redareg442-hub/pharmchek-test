import { type Drug, EGYPTIAN_DRUGS, DRUG_CATEGORIES } from "./drugs-database"

export { DRUG_CATEGORIES }

export interface SearchResult {
  drug: Drug
  relevance: number
  matchType: "scientific" | "commercial" | "category"
}

export function searchDrugs(query: string, filters?: { category?: string; severity?: string }): SearchResult[] {
  if (!query.trim()) return []

  const lowerQuery = query.toLowerCase()
  const results: SearchResult[] = []

  EGYPTIAN_DRUGS.forEach((drug) => {
    let relevance = 0
    let matchType: "scientific" | "commercial" | "category" = "commercial"

    // Check commercial name (highest priority)
    if (drug.commercialName.toLowerCase().includes(lowerQuery)) {
      relevance = drug.commercialName.toLowerCase() === lowerQuery ? 100 : 80
      matchType = "commercial"
    }

    // Check scientific name (medium priority)
    if (drug.scientificName.toLowerCase().includes(lowerQuery)) {
      relevance = Math.max(relevance, drug.scientificName.toLowerCase() === lowerQuery ? 95 : 70)
      matchType = "scientific"
    }

    // Check category (lower priority)
    if (drug.category.toLowerCase().includes(lowerQuery)) {
      relevance = Math.max(relevance, 50)
      matchType = "category"
    }

    // Apply category filter
    if (filters?.category && drug.category !== filters.category) {
      return
    }

    if (relevance > 0) {
      results.push({ drug, relevance, matchType })
    }
  })

  // Sort by relevance (highest first)
  return results.sort((a, b) => b.relevance - a.relevance)
}

export function getRelatedDrugs(drugId: string, limit = 5): Drug[] {
  const drug = EGYPTIAN_DRUGS.find((d) => d.id === drugId)
  if (!drug) return []

  return EGYPTIAN_DRUGS.filter((d) => d.category === drug.category && d.id !== drugId).slice(0, limit)
}

export function getDrugsByCategory(category: string): Drug[] {
  return EGYPTIAN_DRUGS.filter((d) => d.category === category)
}
