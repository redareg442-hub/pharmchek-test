import { INTERACTION_SEVERITY } from "./drugs-database"

export { INTERACTION_SEVERITY }

export interface InteractionAnalysis {
  drug1: string
  drug2: string
  type: string
  severity: "MILD" | "MODERATE" | "SEVERE"
  description: string
  recommendation: string
  sources: string[]
  explanation: string
}

export async function analyzeInteractions(drugs: string[]): Promise<InteractionAnalysis[]> {
  try {
    const response = await fetch("/api/analyze-interactions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ drugs }),
    })

    if (!response.ok) throw new Error("Failed to analyze interactions")

    const data = await response.json()
    return data.interactions || []
  } catch (error) {
    console.error("Error:", error)
    return generateMockInteractions(drugs)
  }
}

function generateMockInteractions(drugs: string[]): InteractionAnalysis[] {
  const interactions: InteractionAnalysis[] = []
  const severities: Array<"MILD" | "MODERATE" | "SEVERE"> = ["MILD", "MODERATE", "SEVERE"]
  const types = ["Pharmacokinetic", "Pharmacodynamic"]

  for (let i = 0; i < drugs.length; i++) {
    for (let j = i + 1; j < drugs.length; j++) {
      interactions.push({
        drug1: drugs[i],
        drug2: drugs[j],
        type: types[Math.floor(Math.random() * types.length)],
        severity: severities[Math.floor(Math.random() * severities.length)],
        description: `Potential ${types[Math.floor(Math.random() * types.length)].toLowerCase()} interaction between ${drugs[i]} and ${drugs[j]}.`,
        recommendation: "Monitor patient closely or consider alternative medication.",
        sources: ["Lexicomp", "Micromedex", "FDA"],
        explanation: "The interaction involves enzyme inhibition or competition for protein binding.",
      })
    }
  }

  return interactions
}
