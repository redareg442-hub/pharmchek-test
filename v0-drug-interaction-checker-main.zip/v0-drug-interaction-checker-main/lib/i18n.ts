export type Language = "en" | "ar"

export const translations = {
  en: {
    // Navigation
    home: "Home",
    checker: "Checker",
    diagnostic: "Diagnostic",
    search: "Search",
    drugs: "Drugs",
    education: "Education",

    // Common
    appName: "PharmCheck",
    appDescription: "AI-powered drug interaction detection",

    // Home Page
    heroTitle: "Detect Drug Interactions with AI",
    heroSubtitle:
      "Comprehensive drug interaction checker for pharmacists, doctors, and pharmacy students. Powered by scientific data and artificial intelligence.",
    startChecking: "Start Checking",
    browseDrugDatabase: "Browse Drug Database",
    keyFeatures: "Key Features",
    aiAssistant: "AI Assistant",
    aiAssistantDesc:
      "Analyze drug interactions with kinetic and dynamic analysis. Get severity levels and therapeutic recommendations.",
    drugDatabase: "Drug Database",
    drugDatabaseDesc: "200+ international drugs with detailed information, mechanisms, and interactions.",
    smartSearch: "Smart Search",
    smartSearchDesc: "Search by scientific name with instant suggestions and category filtering.",
    readyToCheck: "Ready to Check Drug Interactions?",
    readyToCheckDesc:
      "Enter 2 or more drug names to analyze potential interactions and get therapeutic recommendations.",

    // Checker Page
    drugInteractionChecker: "Drug Interaction Checker",
    enterDrugNames: "Enter drug names (scientific names)",
    addDrug: "Add Drug",
    analyzeDrugs: "Analyze Interactions",
    therapeuticPlan: "Therapeutic Plan",
    recommendations: "Recommendations",
    monitoring: "Monitoring Points",
    contraindications: "Contraindications",

    // Education
    educationalResources: "Educational Resources",
    latestScientificArticles: "Latest scientific articles and drug safety information",
    scientificSources: "Scientific Sources",
    lexicomp: "Lexicomp",
    micromedex: "Micromedex",
    whoFda: "WHO & FDA",
    pubmedMedscape: "PubMed & Medscape",

    // Diagnostic
    diagnosticIntelligence: "Diagnostic Intelligence",
    patientAge: "Patient Age",
    liverFunction: "Liver Function",
    kidneyFunction: "Kidney Function",
    comorbidities: "Comorbidities",

    // Drug Database
    drugDatabase: "Drug Database",
    browseByCategory: "Browse by Category",
    searchByScientificName: "Search by Scientific Name",

    // Footer
    designedBy: "Designed and developed by",
    clinicalPharmacyStudent: "Clinical Pharmacy Student at New Mansoura University",
    toSimplifyUnderstanding: "to simplify understanding of drug interactions and improve treatment plans using AI.",
  },
  ar: {
    // Navigation
    home: "الرئيسية",
    checker: "فاحص التفاعلات",
    diagnostic: "التشخيص",
    search: "بحث",
    drugs: "الأدوية",
    education: "التعليم",

    // Common
    appName: "فارمتشيك",
    appDescription: "كاشف تفاعلات الأدوية المدعوم بالذكاء الاصطناعي",

    // Home Page
    heroTitle: "كشف تفاعلات الأدوية باستخدام الذكاء الاصطناعي",
    heroSubtitle: "فاحص شامل لتفاعلات الأدوية للصيادلة والأطباء وطلاب الصيدلة. مدعوم ببيانات علمية والذكاء الاصطناعي.",
    startChecking: "ابدأ الفحص",
    browseDrugDatabase: "استعرض قاعدة بيانات الأدوية",
    keyFeatures: "المميزات الرئيسية",
    aiAssistant: "مساعد ذكي",
    aiAssistantDesc: "حلل تفاعلات الأدوية مع تحليل حركي وديناميكي. احصل على مستويات الخطورة والتوصيات العلاجية.",
    drugDatabase: "قاعدة بيانات الأدوية",
    drugDatabaseDesc: "أكثر من 200 دواء دولي مع معلومات مفصلة والآليات والتفاعلات.",
    smartSearch: "بحث ذكي",
    smartSearchDesc: "ابحث بالاسم العلمي مع اقتراحات فورية وتصفية الفئات.",
    readyToCheck: "هل أنت مستعد للتحقق من تفاعلات الأدوية؟",
    readyToCheckDesc: "أدخل اسمين أو أكثر من أسماء الأدوية لتحليل التفاعلات المحتملة والحصول على التوصيات العلاجية.",

    // Checker Page
    drugInteractionChecker: "فاحص تفاعلات الأدوية",
    enterDrugNames: "أدخل أسماء الأدوية (الأسماء العلمية)",
    addDrug: "إضافة دواء",
    analyzeDrugs: "تحليل التفاعلات",
    therapeuticPlan: "الخطة العلاجية",
    recommendations: "التوصيات",
    monitoring: "نقاط المراقبة",
    contraindications: "موانع الاستعمال",

    // Education
    educationalResources: "الموارد التعليمية",
    latestScientificArticles: "أحدث المقالات العلمية ومعلومات سلامة الأدوية",
    scientificSources: "المصادر العلمية",
    lexicomp: "ليكسيكومب",
    micromedex: "ميكروميديكس",
    whoFda: "منظمة الصحة العالمية وإدارة الغذاء والدواء",
    pubmedMedscape: "بابميد وميدسكيب",

    // Diagnostic
    diagnosticIntelligence: "الذكاء التشخيصي",
    patientAge: "عمر المريض",
    liverFunction: "وظائف الكبد",
    kidneyFunction: "وظائف الكلى",
    comorbidities: "الأمراض المصاحبة",

    // Drug Database
    drugDatabase: "قاعدة بيانات الأدوية",
    browseByCategory: "استعرض حسب الفئة",
    searchByScientificName: "ابحث بالاسم العلمي",

    // Footer
    designedBy: "تم تصميمه وتطويره بواسطة",
    clinicalPharmacyStudent: "طالب الصيدلة السريرية بجامعة المنصورة الجديدة",
    toSimplifyUnderstanding: "لتبسيط فهم تفاعلات الأدوية وتحسين خطط العلاج باستخدام الذكاء الاصطناعي.",
  },
}

export function getTranslation(lang: Language, key: string): string {
  const keys = key.split(".")
  let value: any = translations[lang]

  for (const k of keys) {
    value = value?.[k]
  }

  return value || key
}
