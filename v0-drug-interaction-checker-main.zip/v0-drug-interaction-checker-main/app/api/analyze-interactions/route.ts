import { DRUG_INTERACTIONS_DATABASE } from "@/lib/drugs-database"

export async function POST(request: Request) {
  try {
    const { drugs } = await request.json()

    if (!drugs || drugs.length < 2) {
      return Response.json({ error: "At least 2 drugs required" }, { status: 400 })
    }

    // Free analysis using local database - no API calls needed
    const interactions = analyzeDrugsLocally(drugs)

    return Response.json({ interactions })
  } catch (error) {
    console.error("Error analyzing interactions:", error)
    return Response.json({ error: "Failed to analyze interactions" }, { status: 500 })
  }
}

function analyzeDrugsLocally(drugs: string[]) {
  const interactions = []

  for (let i = 0; i < drugs.length; i++) {
    for (let j = i + 1; j < drugs.length; j++) {
      const drug1 = drugs[i].toLowerCase()
      const drug2 = drugs[j].toLowerCase()

      // Check database for known interactions
      const interaction = DRUG_INTERACTIONS_DATABASE.find(
        (d) =>
          (d.drug1.toLowerCase().includes(drug1) && d.drug2.toLowerCase().includes(drug2)) ||
          (d.drug1.toLowerCase().includes(drug2) && d.drug2.toLowerCase().includes(drug1)),
      )

      if (interaction) {
        interactions.push(interaction)
      } else {
        // Generate safe default response for unknown combinations
        interactions.push({
          drug1: drugs[i],
          drug2: drugs[j],
          type: "unknown",
          severity: "mild",
          description: "No known significant interaction in database",
          recommendation: "Consult with a pharmacist for personalized advice",
          explanation: "This combination is not documented in our current database",
          sources: ["Local Database"],
        })
      }
    }
  }

  return interactions
}
