import { DRUG_INTERACTIONS_DATABASE } from "@/lib/drugs-database"

export async function POST(request: Request) {
  try {
    const { drugs, patientInfo } = await request.json()

    if (!drugs || drugs.length < 1) {
      return Response.json({ error: "At least 1 drug required" }, { status: 400 })
    }

    // Free analysis using local database
    const analysis = performDiagnosticAnalysis(drugs, patientInfo)

    return Response.json({ analysis })
  } catch (error) {
    console.error("Error in diagnostic analysis:", error)
    return Response.json({ error: "Failed to perform diagnostic analysis" }, { status: 500 })
  }
}

function performDiagnosticAnalysis(drugs: string[], patientInfo: any) {
  const interactions = []
  const warnings = []
  const alternatives = []
  const monitoring = []

  // Find all interactions
  for (let i = 0; i < drugs.length; i++) {
    for (let j = i + 1; j < drugs.length; j++) {
      const interaction = DRUG_INTERACTIONS_DATABASE.find(
        (d) =>
          (d.drug1.toLowerCase().includes(drugs[i].toLowerCase()) &&
            d.drug2.toLowerCase().includes(drugs[j].toLowerCase())) ||
          (d.drug1.toLowerCase().includes(drugs[j].toLowerCase()) &&
            d.drug2.toLowerCase().includes(drugs[i].toLowerCase())),
      )

      if (interaction) {
        interactions.push(interaction)
      }
    }
  }

  // Add patient-specific warnings
  if (patientInfo?.age && patientInfo.age > 65) {
    warnings.push("Elderly patient: Monitor for increased side effects and drug accumulation")
  }

  if (patientInfo?.liverFunction === "impaired") {
    warnings.push("Liver impairment: Reduce doses of hepatically metabolized drugs")
  }

  if (patientInfo?.kidneyFunction === "impaired") {
    warnings.push("Kidney impairment: Adjust doses of renally eliminated drugs")
  }

  // Suggest monitoring
  monitoring.push("Monitor for adverse effects regularly")
  monitoring.push("Check drug levels if applicable")
  monitoring.push("Review medication regimen monthly")

  return {
    interactions,
    warnings,
    alternatives,
    monitoring,
    summary: `Analyzed ${drugs.length} medications for patient aged ${patientInfo?.age || "unknown"}. Found ${interactions.length} potential interactions.`,
  }
}
