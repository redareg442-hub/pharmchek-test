"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { BookOpen, AlertCircle, TrendingUp, ExternalLink } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { getTranslation } from "@/lib/i18n"

const educationalBranches = [
  {
    id: "lexicomp",
    title: "Lexicomp",
    description: "Comprehensive drug information database with interactions, dosing, and clinical guidance",
    url: "https://www.wolterskluwer.com/en/solutions/lexicomp",
    icon: BookOpen,
    color: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  },
  {
    id: "micromedex",
    title: "Micromedex",
    description: "Evidence-based clinical decision support system for drug interactions and toxicology",
    url: "https://www.micromedexsolutions.com/",
    icon: BookOpen,
    color: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
  },
  {
    id: "who-fda",
    title: "WHO & FDA",
    description: "Official drug safety alerts, warnings, and regulatory information from health authorities",
    url: "https://www.fda.gov/drugs",
    icon: AlertCircle,
    color: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  },
  {
    id: "pubmed-medscape",
    title: "PubMed & Medscape",
    description: "Latest peer-reviewed research articles and clinical news on drug interactions",
    url: "https://pubmed.ncbi.nlm.nih.gov/",
    icon: TrendingUp,
    color: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  },
]

const educationalContent = [
  {
    id: 1,
    title: "Understanding Pharmacokinetic Interactions",
    source: "PubMed",
    date: "2025-01-15",
    category: "Pharmacology",
    excerpt: "Learn how drugs can interact through absorption, distribution, metabolism, and elimination processes.",
    icon: BookOpen,
    url: "https://pubmed.ncbi.nlm.nih.gov/",
  },
  {
    id: 2,
    title: "Drug Interactions in Elderly Patients",
    source: "WHO",
    date: "2025-01-10",
    category: "Clinical",
    excerpt:
      "Special considerations for managing drug interactions in geriatric populations with multiple comorbidities.",
    icon: AlertCircle,
    url: "https://www.who.int/",
  },
  {
    id: 3,
    title: "Latest FDA Drug Safety Warnings",
    source: "FDA",
    date: "2025-01-08",
    category: "Safety",
    excerpt: "Recent updates on drug safety alerts and contraindications from the FDA.",
    icon: TrendingUp,
    url: "https://www.fda.gov/drugs/drug-safety-and-availability",
  },
  {
    id: 4,
    title: "Cytochrome P450 Enzyme Interactions",
    source: "Medscape",
    date: "2025-01-05",
    category: "Pharmacology",
    excerpt: "Comprehensive guide to CYP450 enzyme-mediated drug interactions and clinical implications.",
    icon: BookOpen,
    url: "https://www.medscape.com/",
  },
  {
    id: 5,
    title: "Drug Interactions with Herbal Supplements",
    source: "Lexicomp",
    date: "2025-01-02",
    category: "Safety",
    excerpt: "Important interactions between pharmaceutical drugs and commonly used herbal products.",
    icon: AlertCircle,
    url: "https://www.wolterskluwer.com/en/solutions/lexicomp",
  },
  {
    id: 6,
    title: "Renal Impairment and Drug Dosing",
    source: "Micromedex",
    date: "2024-12-28",
    category: "Clinical",
    excerpt: "Guidelines for adjusting drug doses in patients with kidney disease.",
    icon: BookOpen,
    url: "https://www.micromedexsolutions.com/",
  },
]

export default function EducationPage() {
  const { language } = useLanguage()
  const t = (key: string) => getTranslation(language, key)

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1 py-8 md:py-12 px-4">
        <div className="container mx-auto max-w-5xl">
          <div className="mb-8 md:mb-12">
            <h1 className="text-2xl md:text-4xl font-bold text-foreground mb-2">{t("educationalResources")}</h1>
            <p className="text-sm md:text-base text-muted-foreground">{t("latestScientificArticles")}</p>
          </div>

          {/* Scientific Sources Section */}
          <div className="mb-8 md:mb-12">
            <h2 className="text-xl md:text-2xl font-bold text-foreground mb-4 md:mb-6">{t("scientificSources")}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-4">
              {educationalBranches.map((branch) => {
                const Icon = branch.icon
                return (
                  <Card key={branch.id} className="p-4 md:p-6 hover:shadow-lg transition-shadow">
                    <div className="flex flex-col sm:flex-row items-start gap-3 md:gap-4">
                      <div className={`p-3 rounded-lg flex-shrink-0 ${branch.color}`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-base md:text-lg text-foreground mb-2">{branch.title}</h3>
                        <p className="text-muted-foreground text-xs md:text-sm mb-4 line-clamp-2">
                          {branch.description}
                        </p>
                        <a href={branch.url} target="_blank" rel="noopener noreferrer">
                          <Button size="sm" variant="outline" className="gap-2 bg-transparent text-xs md:text-sm">
                            Visit Source <ExternalLink className="h-3 w-3 md:h-4 md:w-4" />
                          </Button>
                        </a>
                      </div>
                    </div>
                  </Card>
                )
              })}
            </div>
          </div>

          {/* Latest Articles Section */}
          <div>
            <h2 className="text-xl md:text-2xl font-bold text-foreground mb-4 md:mb-6">Latest Articles</h2>
            <div className="space-y-3 md:space-y-4">
              {educationalContent.map((content) => {
                const Icon = content.icon
                return (
                  <Card key={content.id} className="p-4 md:p-6 hover:shadow-lg transition-shadow">
                    <div className="flex flex-col sm:flex-row gap-3 md:gap-4">
                      <div className="p-3 bg-primary/10 rounded-lg h-fit flex-shrink-0">
                        <Icon className="h-6 w-6 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 mb-2">
                          <h3 className="font-semibold text-base md:text-lg text-foreground">{content.title}</h3>
                          <Badge variant="outline" className="text-xs flex-shrink-0">
                            {content.category}
                          </Badge>
                        </div>
                        <p className="text-muted-foreground text-xs md:text-sm mb-3 line-clamp-2">{content.excerpt}</p>
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                          <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                            <span>Source: {content.source}</span>
                            <span className="hidden sm:inline">•</span>
                            <span>{new Date(content.date).toLocaleDateString()}</span>
                          </div>
                          <a href={content.url} target="_blank" rel="noopener noreferrer" className="flex-shrink-0">
                            <Button size="sm" variant="ghost" className="gap-2 text-xs md:text-sm">
                              Read More <ExternalLink className="h-3 w-3 md:h-4 md:w-4" />
                            </Button>
                          </a>
                        </div>
                      </div>
                    </div>
                  </Card>
                )
              })}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
