"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { searchDrugs, getRelatedDrugs, DRUG_CATEGORIES } from "@/lib/search-utils"
import { Search, TrendingUp, Clock } from "lucide-react"

export default function SearchPage() {
  const [query, setQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [results, setResults] = useState<any[]>([])
  const [recentSearches, setRecentSearches] = useState<string[]>([])
  const [selectedDrug, setSelectedDrug] = useState<any>(null)

  useEffect(() => {
    const saved = localStorage.getItem("recentSearches")
    if (saved) {
      setRecentSearches(JSON.parse(saved))
    }
  }, [])

  const handleSearch = (searchTerm: string) => {
    setQuery(searchTerm)
    const searchResults = searchDrugs(searchTerm, { category: selectedCategory || undefined })
    setResults(searchResults)

    // Save to recent searches
    if (searchTerm.trim()) {
      const updated = [searchTerm, ...recentSearches.filter((s) => s !== searchTerm)].slice(0, 5)
      setRecentSearches(updated)
      localStorage.setItem("recentSearches", JSON.stringify(updated))
    }
  }

  const relatedDrugs = selectedDrug ? getRelatedDrugs(selectedDrug.id) : []

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1 py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-foreground mb-2">Smart Drug Search</h1>
            <p className="text-muted-foreground">Find drugs by name, category, or interactions</p>
          </div>

          {/* Search Bar */}
          <div className="mb-8">
            <div className="relative">
              <Search className="absolute left-4 top-3.5 h-5 w-5 text-muted-foreground" />
              <Input
                placeholder="Search by drug name or category..."
                value={query}
                onChange={(e) => handleSearch(e.target.value)}
                className="pl-12 py-6 text-lg"
              />
            </div>
          </div>

          {/* Category Filter */}
          <div className="mb-8">
            <p className="text-sm font-medium text-foreground mb-3">Filter by Category</p>
            <div className="flex flex-wrap gap-2">
              <Button
                variant={selectedCategory === null ? "default" : "outline"}
                onClick={() => {
                  setSelectedCategory(null)
                  handleSearch(query)
                }}
                size="sm"
              >
                All Categories
              </Button>
              {DRUG_CATEGORIES.map((cat) => (
                <Button
                  key={cat}
                  variant={selectedCategory === cat ? "default" : "outline"}
                  onClick={() => {
                    setSelectedCategory(cat)
                    handleSearch(query)
                  }}
                  size="sm"
                >
                  {cat}
                </Button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Results */}
            <div className="lg:col-span-2">
              {query && results.length > 0 ? (
                <div className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Found {results.length} drug{results.length !== 1 ? "s" : ""}
                  </p>
                  {results.map(({ drug, matchType, relevance }) => (
                    <Card
                      key={drug.id}
                      className="p-6 cursor-pointer hover:shadow-lg transition-all hover:border-primary"
                      onClick={() => setSelectedDrug(drug)}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-semibold text-lg text-foreground">{drug.commercialName}</h3>
                          <p className="text-sm text-muted-foreground">{drug.scientificName}</p>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {matchType === "commercial"
                            ? "Name Match"
                            : matchType === "scientific"
                              ? "Scientific"
                              : "Category"}
                        </Badge>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2">
                          <span className="text-muted-foreground">Category:</span>
                          <Badge>{drug.category}</Badge>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-muted-foreground">Dosage:</span>
                          <span className="text-foreground">
                            {drug.dosageForm} - {drug.dosage}
                          </span>
                        </div>
                        <p className="text-muted-foreground line-clamp-2">{drug.mechanism}</p>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : query ? (
                <Card className="p-12 text-center">
                  <p className="text-muted-foreground">No drugs found matching "{query}"</p>
                </Card>
              ) : (
                <div className="space-y-4">
                  {recentSearches.length > 0 && (
                    <div>
                      <div className="flex items-center gap-2 mb-3">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <p className="text-sm font-medium text-foreground">Recent Searches</p>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {recentSearches.map((search) => (
                          <Button key={search} variant="outline" size="sm" onClick={() => handleSearch(search)}>
                            {search}
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <TrendingUp className="h-4 w-4 text-muted-foreground" />
                      <p className="text-sm font-medium text-foreground">Popular Drugs</p>
                    </div>
                    <div className="space-y-2">
                      {["Amoxil", "Zestril", "Glucophage", "Losec", "Lipitor"].map((drug) => (
                        <Button
                          key={drug}
                          variant="ghost"
                          className="w-full justify-start"
                          onClick={() => handleSearch(drug)}
                        >
                          {drug}
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Drug Details */}
            {selectedDrug && (
              <div className="lg:col-span-1">
                <Card className="p-6 sticky top-24">
                  <h2 className="font-semibold text-lg text-foreground mb-4">{selectedDrug.commercialName}</h2>

                  <div className="space-y-4 text-sm">
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Scientific Name</p>
                      <p className="text-foreground">{selectedDrug.scientificName}</p>
                    </div>

                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Category</p>
                      <Badge>{selectedDrug.category}</Badge>
                    </div>

                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Dosage</p>
                      <p className="text-foreground">
                        {selectedDrug.dosageForm} - {selectedDrug.dosage}
                      </p>
                    </div>

                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Mechanism</p>
                      <p className="text-foreground">{selectedDrug.mechanism}</p>
                    </div>

                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-2">Common Interactions</p>
                      <div className="flex flex-wrap gap-1">
                        {selectedDrug.commonInteractions.map((interaction: string) => (
                          <Badge key={interaction} variant="secondary" className="text-xs">
                            {interaction}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-2">Warnings</p>
                      <ul className="space-y-1">
                        {selectedDrug.warnings.map((warning: string, idx: number) => (
                          <li key={idx} className="text-foreground flex gap-2">
                            <span className="text-destructive">•</span>
                            {warning}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {relatedDrugs.length > 0 && (
                    <div className="mt-6 pt-6 border-t border-border">
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-3">Related Drugs</p>
                      <div className="space-y-2">
                        {relatedDrugs.map((drug) => (
                          <button
                            key={drug.id}
                            onClick={() => setSelectedDrug(drug)}
                            className="w-full text-left px-3 py-2 rounded hover:bg-muted transition-colors text-sm text-foreground"
                          >
                            {drug.commercialName}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </Card>
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
