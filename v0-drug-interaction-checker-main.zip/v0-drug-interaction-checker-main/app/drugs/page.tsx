"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { EGYPTIAN_DRUGS, DRUG_CATEGORIES } from "@/lib/drugs-database"
import { Search } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { getTranslation } from "@/lib/i18n"

export default function DrugsPage() {
  const { language } = useLanguage()
  const t = (key: string) => getTranslation(language, key)

  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  const filteredDrugs = EGYPTIAN_DRUGS.filter((drug) => {
    const matchesSearch = drug.scientificName.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = !selectedCategory || drug.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1 py-8 md:py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="mb-6 md:mb-8">
            <h1 className="text-2xl md:text-4xl font-bold text-foreground mb-2">{t("drugDatabase")}</h1>
            <p className="text-sm md:text-base text-muted-foreground">
              Browse and search 200+ international pharmaceutical drugs
            </p>
          </div>

          {/* Search and Filter */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 md:gap-4 mb-6 md:mb-8">
            <div className="md:col-span-2 relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
              <Input
                placeholder="Search by scientific name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 text-sm"
              />
            </div>
            <select
              value={selectedCategory || ""}
              onChange={(e) => setSelectedCategory(e.target.value || null)}
              className="px-3 md:px-4 py-2 rounded-lg border border-border bg-background text-foreground text-sm"
            >
              <option value="">All Categories</option>
              {DRUG_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
            <div className="text-xs md:text-sm text-muted-foreground flex items-center justify-center md:justify-start">
              {filteredDrugs.length} drug{filteredDrugs.length !== 1 ? "s" : ""} found
            </div>
          </div>

          {/* Drugs Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {filteredDrugs.map((drug) => (
              <Card key={drug.id} className="p-4 md:p-6 hover:shadow-lg transition-shadow">
                <div className="mb-4">
                  <h3 className="font-semibold text-base md:text-lg text-foreground line-clamp-2">
                    {drug.commercialName}
                  </h3>
                  <p className="text-xs md:text-sm text-muted-foreground line-clamp-1">{drug.scientificName}</p>
                </div>

                <div className="space-y-3 text-xs md:text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Category</p>
                    <Badge variant="outline" className="text-xs">
                      {drug.category}
                    </Badge>
                  </div>

                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Dosage</p>
                    <p className="text-foreground text-xs md:text-sm">
                      {drug.dosageForm} - {drug.dosage}
                    </p>
                  </div>

                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Mechanism</p>
                    <p className="text-foreground line-clamp-2 text-xs md:text-sm">{drug.mechanism}</p>
                  </div>

                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Common Interactions</p>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {drug.commonInteractions.slice(0, 2).map((interaction) => (
                        <Badge key={interaction} variant="secondary" className="text-xs">
                          {interaction}
                        </Badge>
                      ))}
                      {drug.commonInteractions.length > 2 && (
                        <Badge variant="secondary" className="text-xs">
                          +{drug.commonInteractions.length - 2}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {filteredDrugs.length === 0 && (
            <Card className="p-8 md:p-12 text-center">
              <p className="text-sm md:text-base text-muted-foreground">
                No drugs found matching your search criteria.
              </p>
            </Card>
          )}
        </div>
      </main>

      <Footer />
    </div>
  )
}
