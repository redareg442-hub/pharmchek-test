"use client"
import { useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { AlertCircle, Plus, X, Loader2, ChevronDown, Pill, Clock, AlertTriangle, CheckCircle2 } from "lucide-react"
import { analyzeInteractions, INTERACTION_SEVERITY } from "@/lib/ai-interactions"
import { EGYPTIAN_DRUGS } from "@/lib/drugs-database"
import { useLanguage } from "@/lib/language-context"
import { getTranslation } from "@/lib/i18n"

interface TherapyPlan {
  dosageSchedule: string[]
  foodConsiderations: string[]
  timingGuidance: string[]
  monitoringTests: string[]
  lifestyleModifications: string[]
  contraindications: string[]
  summary: string
}

export default function CheckerPage() {
  const { language } = useLanguage()
  const t = (key: string) => getTranslation(language, key)

  const [drugs, setDrugs] = useState<string[]>([])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const [results, setResults] = useState<any[]>([])
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [expandedResults, setExpandedResults] = useState<Set<number>>(new Set())
  const [therapyPlan, setTherapyPlan] = useState<TherapyPlan | null>(null)

  const handleInputChange = (value: string) => {
    setInput(value)
    if (value.length > 0) {
      const filtered = EGYPTIAN_DRUGS.filter(
        (drug) =>
          drug.commercialName.toLowerCase().includes(value.toLowerCase()) ||
          drug.scientificName.toLowerCase().includes(value.toLowerCase()),
      )
        .slice(0, 5)
        .map((d) => d.commercialName)
      setSuggestions(filtered)
    } else {
      setSuggestions([])
    }
  }

  const addDrug = (drugName: string) => {
    if (drugName && !drugs.includes(drugName)) {
      setDrugs([...drugs, drugName])
      setInput("")
      setSuggestions([])
    }
  }

  const removeDrug = (drugName: string) => {
    setDrugs(drugs.filter((d) => d !== drugName))
  }

  const generateTherapyPlan = (selectedDrugs: string[]) => {
    const plan: TherapyPlan = {
      dosageSchedule: selectedDrugs.map((drug) => {
        const drugInfo = EGYPTIAN_DRUGS.find((d) => d.commercialName === drug)
        return `${drug}: ${drugInfo?.dosage || "Consult prescriber"} - ${drugInfo?.dosageForm || "as directed"}`
      }),
      foodConsiderations: [
        "Take with food if GI upset occurs",
        "Avoid dairy products 2 hours before/after certain medications",
        "Do not take with grapefruit juice",
      ],
      timingGuidance: [
        "Space medications at least 2 hours apart",
        "Take morning medications with breakfast",
        "Evening medications 1 hour before bedtime",
      ],
      monitoringTests: [
        "Baseline liver function tests (LFTs)",
        "Baseline kidney function (Creatinine, BUN)",
        "Complete blood count (CBC)",
        "Lipid panel if on statins",
        "Blood glucose if on antidiabetics",
      ],
      lifestyleModifications: [
        "Maintain consistent medication schedule",
        "Avoid alcohol consumption",
        "Stay hydrated (8-10 glasses daily)",
        "Regular exercise (30 minutes daily)",
        "Maintain balanced diet",
      ],
      contraindications: selectedDrugs.flatMap((drug) => {
        const drugInfo = EGYPTIAN_DRUGS.find((d) => d.commercialName === drug)
        return drugInfo?.warnings || []
      }),
      summary: `Comprehensive therapy plan for ${selectedDrugs.join(", ")}. Follow dosage schedule strictly and monitor for adverse effects.`,
    }
    return plan
  }

  const handleAnalyze = async () => {
    if (drugs.length < 2) return
    setLoading(true)
    setResults([])
    setTherapyPlan(null)
    try {
      const interactions = await analyzeInteractions(drugs)
      setResults(interactions)
      const plan = generateTherapyPlan(drugs)
      setTherapyPlan(plan)
    } finally {
      setLoading(false)
    }
  }

  const toggleExpanded = (idx: number) => {
    const newExpanded = new Set(expandedResults)
    if (newExpanded.has(idx)) {
      newExpanded.delete(idx)
    } else {
      newExpanded.add(idx)
    }
    setExpandedResults(newExpanded)
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1 py-8 md:py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="mb-6 md:mb-8">
            <h1 className="text-2xl md:text-4xl font-bold text-foreground mb-2">{t("drugInteractionChecker")}</h1>
            <p className="text-sm md:text-base text-muted-foreground">{t("enterDrugNames")}</p>
          </div>

          {/* Warning Banner */}
          <Card className="mb-6 md:mb-8 p-3 md:p-4 bg-yellow-50 dark:bg-yellow-950 border-yellow-200 dark:border-yellow-800">
            <div className="flex gap-2 md:gap-3">
              <AlertCircle className="h-5 w-5 text-yellow-600 dark:text-yellow-400 flex-shrink-0 mt-0.5" />
              <p className="text-xs md:text-sm text-yellow-800 dark:text-yellow-200">
                ⚠️ This is educational information only and is not a substitute for professional medical advice. Always
                consult with a healthcare provider.
              </p>
            </div>
          </Card>

          {/* Input Section */}
          <Card className="p-4 md:p-6 mb-6 md:mb-8">
            <div className="space-y-3 md:space-y-4">
              <div className="relative">
                <Input
                  placeholder="Search drug by name..."
                  value={input}
                  onChange={(e) => handleInputChange(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && addDrug(input)}
                  className="pr-10 text-base"
                />
                {suggestions.length > 0 && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-card border border-border rounded-lg shadow-lg z-10 max-h-48 overflow-y-auto">
                    {suggestions.map((suggestion) => (
                      <button
                        key={suggestion}
                        onClick={() => addDrug(suggestion)}
                        className="w-full text-left px-3 md:px-4 py-2 md:py-3 hover:bg-muted transition-colors first:rounded-t-lg last:rounded-b-lg text-sm md:text-base"
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <Button
                onClick={() => addDrug(input)}
                disabled={!input}
                className="w-full gap-2 text-base md:text-base py-2 md:py-3"
              >
                <Plus className="h-4 w-4" /> {t("addDrug")}
              </Button>

              {drugs.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {drugs.map((drug) => (
                    <Badge key={drug} variant="secondary" className="gap-2 px-2 md:px-3 py-1 text-xs md:text-sm">
                      {drug}
                      <button onClick={() => removeDrug(drug)} className="hover:text-destructive">
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}

              <Button
                onClick={handleAnalyze}
                disabled={drugs.length < 2 || loading}
                size="lg"
                className="w-full text-base py-3"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    Analyzing with AI...
                  </>
                ) : (
                  t("analyzeDrugs")
                )}
              </Button>
            </div>
          </Card>

          {/* Results Section */}
          {results.length > 0 && (
            <div className="space-y-3 md:space-y-4">
              <h2 className="text-xl md:text-2xl font-bold text-foreground">Interaction Results</h2>
              {results.map((interaction, idx) => (
                <Card
                  key={idx}
                  className="border-l-4 border-l-primary overflow-hidden transition-all"
                  onClick={() => toggleExpanded(idx)}
                >
                  <div className="p-4 md:p-6 cursor-pointer hover:bg-muted/50 transition-colors">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-base md:text-lg text-foreground break-words">
                          {interaction.drug1} + {interaction.drug2}
                        </h3>
                        <p className="text-xs md:text-sm text-muted-foreground">{interaction.type}</p>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <Badge
                          className={`${INTERACTION_SEVERITY[interaction.severity]?.color || ""} text-xs md:text-sm`}
                        >
                          {INTERACTION_SEVERITY[interaction.severity]?.label || interaction.severity}
                        </Badge>
                        <ChevronDown
                          className={`h-5 w-5 text-muted-foreground transition-transform flex-shrink-0 ${
                            expandedResults.has(idx) ? "rotate-180" : ""
                          }`}
                        />
                      </div>
                    </div>

                    {expandedResults.has(idx) && (
                      <div className="mt-4 md:mt-6 space-y-3 md:space-y-4 border-t border-border pt-4">
                        <div>
                          <h4 className="font-medium text-foreground mb-2 text-sm md:text-base">Description</h4>
                          <p className="text-xs md:text-sm text-muted-foreground">{interaction.description}</p>
                        </div>

                        <div>
                          <h4 className="font-medium text-foreground mb-2 text-sm md:text-base">Recommendation</h4>
                          <p className="text-xs md:text-sm text-muted-foreground">{interaction.recommendation}</p>
                        </div>

                        <div>
                          <h4 className="font-medium text-foreground mb-2 text-sm md:text-base">
                            Mechanism Explanation
                          </h4>
                          <p className="text-xs md:text-sm text-muted-foreground">{interaction.explanation}</p>
                        </div>

                        <div>
                          <p className="text-xs text-muted-foreground">
                            Sources: {interaction.sources?.join(", ") || "Multiple sources"}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          )}

          {/* Therapy Plan Section */}
          {therapyPlan && (
            <div className="mt-8 md:mt-12 space-y-4 md:space-y-6">
              <h2 className="text-xl md:text-2xl font-bold text-foreground">{t("therapeuticPlan")}</h2>

              {/* Summary */}
              <Card className="p-4 md:p-6 bg-primary/5 border-primary/20">
                <h3 className="font-semibold text-base md:text-lg text-foreground mb-2">Treatment Overview</h3>
                <p className="text-xs md:text-sm text-muted-foreground">{therapyPlan.summary}</p>
              </Card>

              {/* Dosage Schedule */}
              <Card className="p-4 md:p-6 border-l-4 border-l-blue-500">
                <div className="flex items-center gap-2 mb-3 md:mb-4">
                  <Pill className="h-5 w-5 text-blue-500 flex-shrink-0" />
                  <h3 className="font-semibold text-base md:text-lg text-foreground">Dosage Schedule</h3>
                </div>
                <ul className="space-y-2">
                  {therapyPlan.dosageSchedule.map((item, idx) => (
                    <li key={idx} className="text-xs md:text-sm text-muted-foreground flex gap-2">
                      <span className="text-blue-500 flex-shrink-0">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </Card>

              {/* Timing Guidance */}
              <Card className="p-4 md:p-6 border-l-4 border-l-purple-500">
                <div className="flex items-center gap-2 mb-3 md:mb-4">
                  <Clock className="h-5 w-5 text-purple-500 flex-shrink-0" />
                  <h3 className="font-semibold text-base md:text-lg text-foreground">Timing & Administration</h3>
                </div>
                <ul className="space-y-2">
                  {therapyPlan.timingGuidance.map((item, idx) => (
                    <li key={idx} className="text-xs md:text-sm text-muted-foreground flex gap-2">
                      <span className="text-purple-500 flex-shrink-0">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </Card>

              {/* Food Considerations */}
              <Card className="p-4 md:p-6 border-l-4 border-l-green-500">
                <div className="flex items-center gap-2 mb-3 md:mb-4">
                  <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0" />
                  <h3 className="font-semibold text-base md:text-lg text-foreground">Food & Beverage Considerations</h3>
                </div>
                <ul className="space-y-2">
                  {therapyPlan.foodConsiderations.map((item, idx) => (
                    <li key={idx} className="text-xs md:text-sm text-muted-foreground flex gap-2">
                      <span className="text-green-500 flex-shrink-0">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </Card>

              {/* Monitoring Tests */}
              <Card className="p-4 md:p-6 border-l-4 border-l-orange-500">
                <div className="flex items-center gap-2 mb-3 md:mb-4">
                  <AlertTriangle className="h-5 w-5 text-orange-500 flex-shrink-0" />
                  <h3 className="font-semibold text-base md:text-lg text-foreground">Required Monitoring Tests</h3>
                </div>
                <ul className="space-y-2">
                  {therapyPlan.monitoringTests.map((item, idx) => (
                    <li key={idx} className="text-xs md:text-sm text-muted-foreground flex gap-2">
                      <span className="text-orange-500 flex-shrink-0">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </Card>

              {/* Lifestyle Modifications */}
              <Card className="p-4 md:p-6 border-l-4 border-l-teal-500">
                <div className="flex items-center gap-2 mb-3 md:mb-4">
                  <CheckCircle2 className="h-5 w-5 text-teal-500 flex-shrink-0" />
                  <h3 className="font-semibold text-base md:text-lg text-foreground">Lifestyle Modifications</h3>
                </div>
                <ul className="space-y-2">
                  {therapyPlan.lifestyleModifications.map((item, idx) => (
                    <li key={idx} className="text-xs md:text-sm text-muted-foreground flex gap-2">
                      <span className="text-teal-500 flex-shrink-0">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </Card>

              {/* Contraindications */}
              {therapyPlan.contraindications.length > 0 && (
                <Card className="p-4 md:p-6 border-l-4 border-l-red-500">
                  <div className="flex items-center gap-2 mb-3 md:mb-4">
                    <AlertTriangle className="h-5 w-5 text-red-500 flex-shrink-0" />
                    <h3 className="font-semibold text-base md:text-lg text-foreground">Important Warnings</h3>
                  </div>
                  <ul className="space-y-2">
                    {therapyPlan.contraindications.map((item, idx) => (
                      <li key={idx} className="text-xs md:text-sm text-muted-foreground flex gap-2">
                        <span className="text-red-500 flex-shrink-0">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </Card>
              )}
            </div>
          )}

          {!loading && results.length === 0 && drugs.length >= 2 && (
            <Card className="p-8 text-center">
              <p className="text-sm md:text-base text-muted-foreground">
                Click "Analyze Interactions" to see results and therapy plan
              </p>
            </Card>
          )}
        </div>
      </main>

      <Footer />
    </div>
  )
}
