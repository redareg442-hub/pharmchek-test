"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { AlertCircle, Plus, X, Loader2, AlertTriangle, CheckCircle2, Info } from "lucide-react"
import { EGYPTIAN_DRUGS } from "@/lib/drugs-database"
import { useLanguage } from "@/lib/language-context"
import { getTranslation } from "@/lib/i18n"

interface PatientInfo {
  age: string
  liverFunction: string
  kidneyFunction: string
  conditions: string
  allergies: string
  pregnancy: boolean
  breastfeeding: boolean
  alcoholUse: string
  smokingStatus: string
  geneticFactors: string
}

interface DiagnosticAnalysis {
  interactions: string[]
  warnings: string[]
  alternatives: string[]
  monitoring: string[]
  summary: string
}

export default function DiagnosticPage() {
  const { language } = useLanguage()
  const t = (key: string) => getTranslation(language, key)

  const [drugs, setDrugs] = useState<string[]>([])
  const [input, setInput] = useState("")
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [patientInfo, setPatientInfo] = useState<PatientInfo>({
    age: "",
    liverFunction: "Normal",
    kidneyFunction: "Normal",
    conditions: "",
    allergies: "",
    pregnancy: false,
    breastfeeding: false,
    alcoholUse: "None",
    smokingStatus: "Non-smoker",
    geneticFactors: "",
  })
  const [loading, setLoading] = useState(false)
  const [analysis, setAnalysis] = useState<DiagnosticAnalysis | null>(null)

  const handleInputChange = (value: string) => {
    setInput(value)
    if (value.length > 0) {
      const filtered = EGYPTIAN_DRUGS.filter(
        (drug) =>
          drug.commercialName.toLowerCase().includes(value.toLowerCase()) ||
          drug.scientificName.toLowerCase().includes(value.toLowerCase()),
      )
        .slice(0, 5)
        .map((d) => d.commercialName)
      setSuggestions(filtered)
    } else {
      setSuggestions([])
    }
  }

  const addDrug = (drugName: string) => {
    if (drugName && !drugs.includes(drugName)) {
      setDrugs([...drugs, drugName])
      setInput("")
      setSuggestions([])
    }
  }

  const removeDrug = (drugName: string) => {
    setDrugs(drugs.filter((d) => d !== drugName))
  }

  const handleAnalyze = async () => {
    if (drugs.length < 1) return
    setLoading(true)
    try {
      const response = await fetch("/api/diagnostic-analysis", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ drugs, patientInfo }),
      })

      if (!response.ok) throw new Error("Analysis failed")
      const data = await response.json()
      setAnalysis(data.analysis)
    } catch (error) {
      console.error("Error:", error)
      setAnalysis({
        interactions: ["Unable to fetch analysis"],
        warnings: [],
        alternatives: [],
        monitoring: [],
        summary: "Please try again",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />

      <main className="flex-1 py-8 md:py-12 px-4">
        <div className="container mx-auto max-w-5xl">
          <div className="mb-6 md:mb-8">
            <h1 className="text-2xl md:text-4xl font-bold text-foreground mb-2">{t("diagnosticIntelligence")}</h1>
            <p className="text-sm md:text-base text-muted-foreground">
              Analyze complete medication regimens with comprehensive patient-specific considerations
            </p>
          </div>

          {/* Warning Banner */}
          <Card className="mb-6 md:mb-8 p-3 md:p-4 bg-yellow-50 dark:bg-yellow-950 border-yellow-200 dark:border-yellow-800">
            <div className="flex gap-2 md:gap-3">
              <AlertCircle className="h-5 w-5 text-yellow-600 dark:text-yellow-400 flex-shrink-0 mt-0.5" />
              <p className="text-xs md:text-sm text-yellow-800 dark:text-yellow-200">
                ⚠️ This analysis is for educational purposes. Always consult healthcare professionals for clinical
                decisions.
              </p>
            </div>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
            {/* Input Section */}
            <div className="lg:col-span-1">
              <Card className="p-4 md:p-6 lg:sticky lg:top-24">
                <h2 className="font-semibold text-base md:text-lg text-foreground mb-4">Patient Information</h2>

                <div className="space-y-3 md:space-y-4 max-h-[80vh] overflow-y-auto">
                  {/* Basic Info */}
                  <div>
                    <label className="text-xs md:text-sm font-medium text-foreground block mb-2">
                      {t("patientAge")}
                    </label>
                    <Input
                      type="number"
                      placeholder="e.g., 65"
                      value={patientInfo.age}
                      onChange={(e) => setPatientInfo({ ...patientInfo, age: e.target.value })}
                      className="text-sm"
                    />
                  </div>

                  {/* Organ Function */}
                  <div>
                    <label className="text-xs md:text-sm font-medium text-foreground block mb-2">
                      {t("liverFunction")}
                    </label>
                    <select
                      value={patientInfo.liverFunction}
                      onChange={(e) => setPatientInfo({ ...patientInfo, liverFunction: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm"
                    >
                      <option>Normal</option>
                      <option>Mild Impairment</option>
                      <option>Moderate Impairment</option>
                      <option>Severe Impairment</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs md:text-sm font-medium text-foreground block mb-2">
                      {t("kidneyFunction")}
                    </label>
                    <select
                      value={patientInfo.kidneyFunction}
                      onChange={(e) => setPatientInfo({ ...patientInfo, kidneyFunction: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm"
                    >
                      <option>Normal</option>
                      <option>Mild Impairment</option>
                      <option>Moderate Impairment</option>
                      <option>Severe Impairment</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs md:text-sm font-medium text-foreground block mb-2">Comorbidities</label>
                    <Input
                      placeholder="e.g., Diabetes, Hypertension"
                      value={patientInfo.conditions}
                      onChange={(e) => setPatientInfo({ ...patientInfo, conditions: e.target.value })}
                      className="text-sm"
                    />
                  </div>

                  <div>
                    <label className="text-xs md:text-sm font-medium text-foreground block mb-2">Drug Allergies</label>
                    <Input
                      placeholder="e.g., Penicillin, NSAIDs"
                      value={patientInfo.allergies}
                      onChange={(e) => setPatientInfo({ ...patientInfo, allergies: e.target.value })}
                      className="text-sm"
                    />
                  </div>

                  <div>
                    <label className="text-xs md:text-sm font-medium text-foreground block mb-2">Alcohol Use</label>
                    <select
                      value={patientInfo.alcoholUse}
                      onChange={(e) => setPatientInfo({ ...patientInfo, alcoholUse: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm"
                    >
                      <option>None</option>
                      <option>Occasional</option>
                      <option>Moderate</option>
                      <option>Heavy</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs md:text-sm font-medium text-foreground block mb-2">Smoking Status</label>
                    <select
                      value={patientInfo.smokingStatus}
                      onChange={(e) => setPatientInfo({ ...patientInfo, smokingStatus: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm"
                    >
                      <option>Non-smoker</option>
                      <option>Former Smoker</option>
                      <option>Current Smoker</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="pregnancy"
                      checked={patientInfo.pregnancy}
                      onChange={(e) => setPatientInfo({ ...patientInfo, pregnancy: e.target.checked })}
                      className="rounded border-border w-4 h-4"
                    />
                    <label
                      htmlFor="pregnancy"
                      className="text-xs md:text-sm font-medium text-foreground cursor-pointer"
                    >
                      Pregnant
                    </label>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="breastfeeding"
                      checked={patientInfo.breastfeeding}
                      onChange={(e) => setPatientInfo({ ...patientInfo, breastfeeding: e.target.checked })}
                      className="rounded border-border w-4 h-4"
                    />
                    <label
                      htmlFor="breastfeeding"
                      className="text-xs md:text-sm font-medium text-foreground cursor-pointer"
                    >
                      Breastfeeding
                    </label>
                  </div>

                  <div>
                    <label className="text-xs md:text-sm font-medium text-foreground block mb-2">Genetic Factors</label>
                    <Input
                      placeholder="e.g., CYP2D6 poor metabolizer"
                      value={patientInfo.geneticFactors}
                      onChange={(e) => setPatientInfo({ ...patientInfo, geneticFactors: e.target.value })}
                      className="text-sm"
                    />
                  </div>

                  <div className="border-t border-border pt-3 md:pt-4">
                    <h3 className="font-medium text-foreground mb-3 text-sm md:text-base">Medications</h3>
                    <div className="relative mb-3">
                      <Input
                        placeholder="Search drug..."
                        value={input}
                        onChange={(e) => handleInputChange(e.target.value)}
                        onKeyPress={(e) => e.key === "Enter" && addDrug(input)}
                        className="text-sm"
                      />
                      {suggestions.length > 0 && (
                        <div className="absolute top-full left-0 right-0 mt-2 bg-card border border-border rounded-lg shadow-lg z-10 max-h-40 overflow-y-auto">
                          {suggestions.map((suggestion) => (
                            <button
                              key={suggestion}
                              onClick={() => addDrug(suggestion)}
                              className="w-full text-left px-3 py-2 hover:bg-muted transition-colors text-xs md:text-sm"
                            >
                              {suggestion}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    <Button
                      onClick={() => addDrug(input)}
                      disabled={!input}
                      size="sm"
                      className="w-full gap-2 mb-3 text-xs md:text-sm"
                    >
                      <Plus className="h-3 w-3" /> Add Drug
                    </Button>

                    {drugs.length > 0 && (
                      <div className="space-y-2">
                        {drugs.map((drug) => (
                          <div
                            key={drug}
                            className="flex items-center justify-between bg-muted p-2 rounded text-xs md:text-sm"
                          >
                            <span className="text-foreground truncate">{drug}</span>
                            <button
                              onClick={() => removeDrug(drug)}
                              className="text-muted-foreground hover:text-destructive flex-shrink-0"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <Button
                    onClick={handleAnalyze}
                    disabled={drugs.length < 1 || loading}
                    size="lg"
                    className="w-full text-sm md:text-base py-2 md:py-3"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        Analyzing...
                      </>
                    ) : (
                      "Analyze Regimen"
                    )}
                  </Button>
                </div>
              </Card>
            </div>

            {/* Results Section */}
            <div className="lg:col-span-2">
              {analysis && (
                <div className="space-y-3 md:space-y-4">
                  {/* Summary */}
                  <Card className="p-4 md:p-6 bg-primary/5 border-primary/20">
                    <h3 className="font-semibold text-base md:text-lg text-foreground mb-2">Analysis Summary</h3>
                    <p className="text-xs md:text-sm text-muted-foreground">{analysis.summary}</p>
                  </Card>

                  {/* Interactions */}
                  {analysis.interactions && analysis.interactions.length > 0 && (
                    <Card className="p-4 md:p-6 border-l-4 border-l-destructive">
                      <div className="flex items-center gap-2 mb-3">
                        <AlertTriangle className="h-5 w-5 text-destructive flex-shrink-0" />
                        <h3 className="font-semibold text-base md:text-lg text-foreground">Drug Interactions</h3>
                      </div>
                      <ul className="space-y-2">
                        {analysis.interactions.map((interaction, idx) => (
                          <li key={idx} className="text-xs md:text-sm text-muted-foreground flex gap-2">
                            <span className="text-destructive flex-shrink-0">•</span>
                            <span>{interaction}</span>
                          </li>
                        ))}
                      </ul>
                    </Card>
                  )}

                  {/* Warnings */}
                  {analysis.warnings && analysis.warnings.length > 0 && (
                    <Card className="p-4 md:p-6 border-l-4 border-l-orange-500">
                      <div className="flex items-center gap-2 mb-3">
                        <AlertCircle className="h-5 w-5 text-orange-500 flex-shrink-0" />
                        <h3 className="font-semibold text-base md:text-lg text-foreground">Special Warnings</h3>
                      </div>
                      <ul className="space-y-2">
                        {analysis.warnings.map((warning, idx) => (
                          <li key={idx} className="text-xs md:text-sm text-muted-foreground flex gap-2">
                            <span className="text-orange-500 flex-shrink-0">•</span>
                            <span>{warning}</span>
                          </li>
                        ))}
                      </ul>
                    </Card>
                  )}

                  {/* Monitoring */}
                  {analysis.monitoring && analysis.monitoring.length > 0 && (
                    <Card className="p-4 md:p-6 border-l-4 border-l-accent">
                      <div className="flex items-center gap-2 mb-3">
                        <Info className="h-5 w-5 text-accent flex-shrink-0" />
                        <h3 className="font-semibold text-base md:text-lg text-foreground">
                          Monitoring Recommendations
                        </h3>
                      </div>
                      <ul className="space-y-2">
                        {analysis.monitoring.map((item, idx) => (
                          <li key={idx} className="text-xs md:text-sm text-muted-foreground flex gap-2">
                            <span className="text-accent flex-shrink-0">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </Card>
                  )}

                  {/* Alternatives */}
                  {analysis.alternatives && analysis.alternatives.length > 0 && (
                    <Card className="p-4 md:p-6 border-l-4 border-l-green-500">
                      <div className="flex items-center gap-2 mb-3">
                        <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0" />
                        <h3 className="font-semibold text-base md:text-lg text-foreground">Suggested Alternatives</h3>
                      </div>
                      <ul className="space-y-2">
                        {analysis.alternatives.map((alt, idx) => (
                          <li key={idx} className="text-xs md:text-sm text-muted-foreground flex gap-2">
                            <span className="text-green-500 flex-shrink-0">•</span>
                            <span>{alt}</span>
                          </li>
                        ))}
                      </ul>
                    </Card>
                  )}
                </div>
              )}

              {!loading && !analysis && drugs.length > 0 && (
                <Card className="p-8 md:p-12 text-center">
                  <p className="text-xs md:text-sm text-muted-foreground">
                    Click "Analyze Regimen" to see comprehensive analysis
                  </p>
                </Card>
              )}

              {!loading && !analysis && drugs.length === 0 && (
                <Card className="p-8 md:p-12 text-center">
                  <p className="text-xs md:text-sm text-muted-foreground">Add medications to begin analysis</p>
                </Card>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
