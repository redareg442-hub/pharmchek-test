"use client"

import { useLanguage } from "@/lib/language-context"
import { getTranslation } from "@/lib/i18n"

export function Footer() {
  const { language } = useLanguage()
  const t = (key: string) => getTranslation(language, key)

  return (
    <footer className="border-t border-border bg-muted/50 py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="font-semibold text-foreground mb-4">About PharmCheck</h3>
            <p className="text-sm text-muted-foreground">
              {t("designedBy")} Reda Mostafa, {t("clinicalPharmacyStudent")} {t("toSimplifyUnderstanding")}
            </p>
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-4">{t("scientificSources")}</h3>
            <ul className="text-sm text-muted-foreground space-y-2">
              <li>{t("lexicomp")}</li>
              <li>{t("micromedex")}</li>
              <li>{t("whoFda")}</li>
              <li>{t("pubmedMedscape")}</li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-4">Disclaimer</h3>
            <p className="text-sm text-muted-foreground">
              ⚠️ This website is for educational purposes only and is not a substitute for professional medical advice.
            </p>
          </div>
        </div>
        <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; 2025 PharmCheck. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
